from django.conf.urls import url
from . import views #controller file

urlpatterns = [
    url(r'^$', views.index),
    url(r'^ninjas$', views.ninjas),
    url(r'^users/(?P<id>\d+)$', views.show),
    url(r'^ninjas/(?P<ninja_color>\w+)$', views.showninja, name ='show'),

]
