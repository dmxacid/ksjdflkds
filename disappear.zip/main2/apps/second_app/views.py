from django.shortcuts import render

# Create your views here.
def index(request):
    context = {
        "email": "blog@gmail.com",
        "name": "Mike"
    }
    #  context = {'myninja' : ninja}
    return render(request, "second_app/index.html", context)
def show(request, id):
    context = {
        "id" : id
    }
    #  context = {'myninja' : ninja}
    return render(request, "second_app/show.html", context)
def ninjas(request):
    return render(request, "second_app/ninjas.html")
def showninja(request, ninja_color):
    turtle_options = {
        'red':'second_app/images/raphael.jpg',
        'blue':'second_app/images/leonardo.jpg',
        'orange':'second_app/images/michelangelo.jpg',
        'purple':'second_app/images/donatello.jpg'
    }
    if ninja_color in turtle_options:
        context = {
            'image':turtle_options[ninja_color]
        }
    else:
        context = {
            'image':'second_app/images/notapril.jpg'
        }
    # return render(request, "second_app/show.html", context)
    return render(request, "second_app/showninjas.html", context)
